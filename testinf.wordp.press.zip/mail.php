
<html lang="zh-CN"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=640px,user-scalable=no">
<?php
$to = "SHABANOV070707@GMAIL.COM";
$subject = "Новая заявка Лазерной Эпиляции";
$message = "Имя: ".$_GET['name']."<br> Телефон: ".$_GET['phone']."";
$headers = "From: MyRusakov.ru <abc@wingderm.com.ua>\r\nContent-type: text/html; charset=windows-1251 \r\n";
mail ($to, $subject, $message, $headers);

 ?>


    <title>Диодный лазер Lasermach</title>
    <meta name="keywords" content="Wingderm Electro-Optics Ltd.">
<meta name="description" content="Wingderm Electro-Optics Ltd.">
 <link href="/favicon.ico" rel="shortcut icon">
<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script src="/Public/home/js/jquery.min.js"></script>
<script src="/Public/home/js/swiper.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<![endif]-->
<link rel="stylesheet" href="/Public/home/css/swiper.min.css">
<link href="/Public/home/css/style.css" rel="stylesheet" type="text/css">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-126687633-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-126687633-1');
</script>

<script src="/Public/home/js/nav.js" type="text/javascript" defer="defer"></script>
<script type="text/javascript">
$(function(){
    $(".nav_pro").click(function(){
        $.scrollTo('#pro',500);
    });
});
</script>

    <style>
        .footer{margin-top:0px;}
         #cnav{ z-index:99999;}
    </style><!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<![endif]-->
<link href="/Public/yun/css/animate.min.css" rel="stylesheet" type="text/css">
    <link href="/Public/yun/css/index.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/en.css" rel="stylesheet" type="text/css">
</head><div id="screen-shader" style="
            transition: opacity 0.1s ease 0s;
            z-index: 2147483647;
            margin: 0;
            border-radius: 0;
            padding: 0;
            background: #fac563;
            pointer-events: none;
            position: fixed;
            top: -10%;
            right: -10%;
            width: 120%;
            height: 120%;
            opacity: 0.2000;
            mix-blend-mode: multiply;
            display: none;
        "></div>
<body cz-shortcut-listen="true">



<div id="navbox">
    <div class="children" style="display:none;"></div>
    <div class="children container" style="display:none;">
           <div class="chleft">
           <ul class="xnav">
             <h3><b>Product</b></h3>
                                       <li id="c1" onmouseover="setContentTab('c',1,100)"><a href="/Home/Index/chan_tuji.html?id=5">Lasermach™ Pro</a></li>             <li id="c2" onmouseover="setContentTab('c',2,100)"><a href="/Home/Index/chan_tuji.html?id=6">MesoSkin™</a></li>             <li id="c3" onmouseover="setContentTab('c',3,100)"><a href="/Home/Index/chan_tuji.html?id=7">WeShape™ Pro</a></li>             <span><a href="/Home/Index/chan.html">See More</a></span>
           </ul>

           <ul class="xnav">
             <h3><b>Treatment Regimen</b></h3>
                          <li id="c4" onmouseover="setContentTab('c',4,100)"><a href="/Home/Index/chan.html?fid=32">Hair Removal</a></li>             <li id="c5" onmouseover="setContentTab('c',5,100)"><a href="/Home/Index/chan.html?fid=33">Body Contouring</a></li>             <li id="c6" onmouseover="setContentTab('c',6,100)"><a href="/Home/Index/chan.html?fid=34">Moisturizing Tightening</a></li>             <li id="c7" onmouseover="setContentTab('c',7,100)"><a href="/Home/Index/chan.html?fid=35">Cellulite</a></li>             <li id="c8" onmouseover="setContentTab('c',8,100)"><a href="/Home/Index/chan.html?fid=36">Skin Renewal</a></li>             <span><a href="/Home/Index/fangan.html">See More</a></span>
           </ul>
           </div>

           <div class="chright">
                                                   <div class="chimg" id="con_c_1" style="display:block;"><img src="/Uploads/20181210/5c0e0aff72f44.png"></div>                    <div class="chimg" id="con_c_2"><img src="/Uploads/20170911/59b63cb0b14e3.jpg"></div>                    <div class="chimg" id="con_c_3"><img src="/Uploads/20170929/59cdaae62d887.jpg"></div>
                                <div class="chimg" id="con_c_4"><img src="/Uploads/20170714/5968774031c92.jpg"></div>                <div class="chimg" id="con_c_5"><img src="/Uploads/20170714/59686c3487c9d.jpg"></div>                <div class="chimg" id="con_c_6"><img src="/Uploads/20170714/59686c60a7691.jpg"></div>                <div class="chimg" id="con_c_7"><img src="/Uploads/20170714/59686caee683e.jpg"></div>                <div class="chimg" id="con_c_8"><img src="/Uploads/20170714/59686cfb47ab5.jpg"></div>           </div>

    </div>

</div>


<!--手机导航-->
<ul class="wapnav" style="display:none;">
<li class="item-has-child ">
<a href="javascript:void()" class="drop-arrow"><b>Product</b></a>
<ul class="dropdown">
      <li><a href="/Home/Index/chan_tuji.html?id=5">Lasermach™ Pro</a></li><li><a href="/Home/Index/chan_tuji.html?id=6">MesoSkin™</a></li><li><a href="/Home/Index/chan_tuji.html?id=7">WeShape™ Pro</a></li>           <li><a href="/Home/Index/chan.html?id=7">See More</a></li>
</ul>
</li>
<li class="item-has-child ">
<a href="javascript:void()" class="drop-arrow"><b>Treatment Regimen</b></a>
<ul class="dropdown">
    <li><a href="/Home/Index/chan.html?fid=32">Hair Removal</a></li><li><a href="/Home/Index/chan.html?fid=41">Laser Hair</a></li><li><a href="/Home/Index/chan.html?fid=42">Acne</a></li><li><a href="/Home/Index/chan.html?fid=43">Relieve Pain</a></li><li><a href="/Home/Index/chan.html?fid=33">Body Contouring</a></li>        <li><a href="/Home/Index/fangan.html?id=7">See More</a></li>
</ul>
</li>

<li class="item-has-child "><a href="javascript:void()" class="drop-arrow">WingCloud</a></li>

<li class="item-has-child ">
<a href="javascript:void()" class="drop-arrow"><b>About Wingderm</b></a>
<ul class="dropdown">
     <li><a href="/Home/Index/news?id=179">News</a></li><li><a href="/Home/Index/news?id=182">Exhibition</a></li><li><a href="/Home/Index/lianxi?id=181">Contact Us</a></li></ul>

</li>


</ul>
<!--手机导航-->
<!-- <div class="cpban" style="background:url(/Uploads/20180914/5b9b721d5bc80.jpg) no-repeat center center;-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; "><img src="/Uploads/20180914/5b9b721d5bc80.jpg"></div>  -->
<div class="header">
    <div class="container" style="position:relative;">
        <div class="logos"><a href="tel:+38 (099) 519-19-03">+38 (099) 519-19-03</a>
          <br>
            <a href="tel:+38(067) 323-56-97">+38(067) 323-56-97</a></div>


    <div class="logos">&nbsp;&nbsp;&nbsp;Киев, ул. Хорива, 3/А | График работы: Пн-Вс: 09:00 - 21:00</div>





    </div>
 </div>
<!--part2-->
<div class="part2 pr">
    <img src="/Public/yun/images/datu2.jpg" alt="" class="pc">
    <img src="/Public/yun/images/datu2_640.jpg" alt="" class="mt">
    <div class="descrip">
        <div class="zitest animated op fadeInUp" data-animation="fadeInUp">
            <img src="/Public/yun/images/part2_io.png" alt="">
            <br>
            <span>Спасибо!<br>Ваша заявка отправлена</span>

        </div>
        <p class="zitest animated delay3 fadeInUp" data-animation="fadeInUp">Лучший выбор для услуг по Лазерной Эпиляции!</p>

    </div>
</div>





<iframe id="frame-onFontResize1590004582000" style="width: 100em; height: 10px; position: absolute; border-width: 0px; top: -5000px; left: -5000px;"></iframe></body></html>
